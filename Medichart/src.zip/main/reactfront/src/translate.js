import React from "react";
function Translate() {
  return <div>건강진단 해석</div>;
}

export default Translate;
