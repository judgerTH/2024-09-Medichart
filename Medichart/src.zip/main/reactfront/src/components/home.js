import bannger from "../logo.svg";

function Home() {
  return (
    <div>
      <img src={bannger}></img>
    </div>
  );
}
export default Home;
