import React from "react";
function Footer() {
  return (
    <footer>
      <div>푸터자리</div>
    </footer>
  );
}

export default Footer;
