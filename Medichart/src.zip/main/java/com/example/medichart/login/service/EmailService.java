package com.example.medichart.login.service;

public interface EmailService {
    void sendEmail(String to, String subject, String text);
}