package com.example.medichart.admin.repository;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

public interface MockUserRepository {

    long countBySignupDate(LocalDate signupDate);

    List<Long> countBySignupDateBetween(LocalDate startDate, LocalDate endDate);

    List<Long> countBySignupMonthBetween(YearMonth startYearMonth, YearMonth endYearMonth);

    List<Long> countBySignupYearBetween(int startYear, int endYear);
}